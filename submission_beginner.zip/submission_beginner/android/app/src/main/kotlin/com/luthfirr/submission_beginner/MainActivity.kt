package com.luthfirr.submission_beginner

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
